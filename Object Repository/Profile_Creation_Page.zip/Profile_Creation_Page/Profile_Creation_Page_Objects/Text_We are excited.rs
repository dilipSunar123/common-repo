<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Text_We are excited</name>
   <tag></tag>
   <elementGuidId>9397e2ff-a6dc-4dda-8b24-98335673a6c1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p.mb-2.p-0</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div/div[2]/p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>93be0f1b-c4de-4246-a67e-657b3d22b389</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mb-2 p-0</value>
      <webElementGuid>79014a4e-118b-4ba6-8215-bdf667877130</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>We are excited that you took the next step to build your profile. Sharing more information will help us match you with a Companion who shares your interests and values. As we begin, please consider sharing information in the following sequence:</value>
      <webElementGuid>aee618b7-15ec-4dda-b429-b9e48fca321c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;App&quot;]/div[@class=&quot;body-side--container inner-wrapper&quot;]/div[@class=&quot;px-2&quot;]/div[@class=&quot;row p-0&quot;]/p[@class=&quot;mb-2 p-0&quot;]</value>
      <webElementGuid>de97976b-b354-4fc3-8b85-df5afaae2c01</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[2]/p</value>
      <webElementGuid>f0bd67f8-fa37-43b7-9640-14d0248f6071</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View a sample profile'])[1]/following::p[1]</value>
      <webElementGuid>94129c14-bb25-4a7b-9fd1-97d69e437fba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Yuvaraj'])[1]/following::p[1]</value>
      <webElementGuid>8870f017-420f-4cd8-8626-db8bf7413460</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='I want to type'])[1]/preceding::p[7]</value>
      <webElementGuid>0d12f3f1-fe65-450c-a8df-15fc22abd5b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='We are excited that you took the next step to build your profile. Sharing more information will help us match you with a']/parent::*</value>
      <webElementGuid>1279539e-3b43-4539-9434-42dd331f4256</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/p</value>
      <webElementGuid>220cab62-f30f-4e40-8160-69a1ddd8bb60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'We are excited that you took the next step to build your profile. Sharing more information will help us match you with a Companion who shares your interests and values. As we begin, please consider sharing information in the following sequence:' or . = 'We are excited that you took the next step to build your profile. Sharing more information will help us match you with a Companion who shares your interests and values. As we begin, please consider sharing information in the following sequence:')]</value>
      <webElementGuid>c30b898e-2095-433f-bab0-28e1fd49f0f8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
