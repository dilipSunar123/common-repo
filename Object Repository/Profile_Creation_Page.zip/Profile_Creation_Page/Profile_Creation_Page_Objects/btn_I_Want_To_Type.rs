<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_I_Want_To_Type</name>
   <tag></tag>
   <elementGuidId>0de10658-bdf5-4b25-826d-c2ff3d95f70b</elementGuidId>
   <imagePath></imagePath>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*/text()[normalize-space(.)='I want to type']/parent::*</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = ' I want to type' or . = ' I want to type')]</value>
      </entry>
      <entry>
         <key>IMAGE</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>e766cf41-485e-44f7-a46e-da38568e56ce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value> secondary w-100 px-md-0  </value>
      <webElementGuid>69be4ccc-e5cb-4eec-bcae-cd1d12e9e304</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> I want to type</value>
      <webElementGuid>ef3ca085-5026-4449-b64f-ae45a4723de4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;App&quot;]/div[@class=&quot;body-side--container inner-wrapper&quot;]/div[@class=&quot;px-2&quot;]/div[@class=&quot;row mb-1&quot;]/div[@class=&quot;col-12 col-md-5 col-lg-4 col-xl-4 p-0 h-25 row justify-content-start&quot;]/div[@class=&quot;d-flex justify-content-around col-12 col-sm-6&quot;]/button[@class=&quot;secondary w-100 px-md-0&quot;]</value>
      <webElementGuid>492bb800-c65e-452a-8215-72961dc5fece</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[4]/div/div[2]/button</value>
      <webElementGuid>edea459b-373c-4797-a6fc-d0c535f7da9a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View a sample profile'])[1]/following::button[2]</value>
      <webElementGuid>6c4b8c14-7103-4a17-80d0-1e5026a9e44d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Voice Recorder'])[1]/preceding::button[1]</value>
      <webElementGuid>0a47780f-8f4d-43ee-ae6a-ffe676edb212</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Next'])[1]/preceding::button[2]</value>
      <webElementGuid>ca33b133-d8ee-42d3-8fb4-b632aa1bda0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='I want to type']/parent::*</value>
      <webElementGuid>7c7f6648-78ce-4d9d-b52c-150ef71b9db0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div[2]/button</value>
      <webElementGuid>5aac129e-e2f0-4fc4-a232-a0b65d735afa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = ' I want to type')]</value>
      <webElementGuid>608361bd-8d7b-4bfb-be5a-2555e24e48fc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
