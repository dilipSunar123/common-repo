<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_I_Want_To_Speak</name>
   <tag></tag>
   <elementGuidId>9e216cfd-8dc3-42ff-85e7-cfd99633d491</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[(text() = ' I want to speak')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>d53f90be-4f13-4506-a781-4023a598c2f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value> secondary w-100 px-md-0 active</value>
      <webElementGuid>c2832867-c90e-4356-8d2d-d8e2d2a4a23d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> I want to speak</value>
      <webElementGuid>12e9ae51-aade-46c9-b0cb-be446948acea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;App&quot;]/div[@class=&quot;body-side--container inner-wrapper&quot;]/div[@class=&quot;px-2&quot;]/div[@class=&quot;row mb-1&quot;]/div[@class=&quot;col-12 col-md-5 col-lg-4 col-xl-4 p-0 h-25 row justify-content-start&quot;]/div[@class=&quot;d-flex justify-content-around col-12 col-sm-6 my-2 my-sm-0&quot;]/button[@class=&quot;secondary w-100 px-md-0 active&quot;]</value>
      <webElementGuid>11ced400-f13f-476c-9a47-aa2adac13151</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[4]/div/div/button</value>
      <webElementGuid>3e4d33fe-ef8c-4f3c-9555-90dd4498d68f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View a sample profile'])[1]/following::button[1]</value>
      <webElementGuid>4797d68d-774d-4019-bfbc-d59cd8654377</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Palak'])[1]/following::button[2]</value>
      <webElementGuid>b0589f23-41a0-4cde-8d9c-cbd5b79e22f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='I want to type'])[1]/preceding::button[1]</value>
      <webElementGuid>61b8b49e-8f42-4056-9040-b5ac8547abc4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Voice Recorder'])[1]/preceding::button[2]</value>
      <webElementGuid>58cdc126-a52b-4fba-87f7-f513c0af7fe9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='I want to speak']/parent::*</value>
      <webElementGuid>49f25e0d-100b-4b42-856d-2b586d1a47bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div/button</value>
      <webElementGuid>a36e79d1-426d-4578-8174-04e876390764</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = ' I want to speak')]</value>
      <webElementGuid>642c710c-4a09-4ec9-9228-0dd7043cf08a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
