<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Text_Select the button of your choice to create your profile</name>
   <tag></tag>
   <elementGuidId>7356a3a1-a044-491b-94a8-69b35fbb1285</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p.h6.m-0.p-0</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div/div[3]/div/p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>97a4ade9-d58e-4631-96a7-f401067856c1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>h6 m-0 p-0</value>
      <webElementGuid>0f854bda-ba74-4d32-8177-ac5cee606881</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select the button of your choice to create your profile:</value>
      <webElementGuid>ecbb02bc-2a63-40af-9a64-f36281b9f50f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;App&quot;]/div[@class=&quot;body-side--container inner-wrapper&quot;]/div[@class=&quot;px-2&quot;]/div[@class=&quot;row mx-2 mb-3 p-0&quot;]/div[@class=&quot;col-11 col-md-10 col-lg-7 col-xl-7 p-0 h-25 row justify-content-start&quot;]/p[@class=&quot;h6 m-0 p-0&quot;]</value>
      <webElementGuid>76a695fe-c55e-4ca6-9d36-e31fb6084c72</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[3]/div/p</value>
      <webElementGuid>c8c6128f-8cdc-49cd-8427-277f3baeee27</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View a sample profile'])[1]/following::p[7]</value>
      <webElementGuid>0391be9c-c518-45fd-ac15-6332b7531286</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Yuvaraj'])[1]/following::p[7]</value>
      <webElementGuid>a4e781f3-f13e-46c3-8419-1e000c7b3548</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='I want to type'])[1]/preceding::p[1]</value>
      <webElementGuid>0d6d4489-7202-431a-9c6b-bdd81ae384d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Select the button of your choice to create your profile:']/parent::*</value>
      <webElementGuid>235d6cc2-6f5f-43ca-82ed-01526915e73e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/p</value>
      <webElementGuid>6727c19c-5481-4d33-abd3-320667c881e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Select the button of your choice to create your profile:' or . = 'Select the button of your choice to create your profile:')]</value>
      <webElementGuid>a2b9f2bd-1fbd-4e9d-a3e5-a469f084ae07</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
